from django.shortcuts import render
from django.views import generic
from .models import Author, Book, Comment
from django.db.models import Q
from .forms import SearchForm
from orders.forms import CartAddBookForm
from django.http import Http404

# Create your views here.

"""
Función para implementar la pantalla de inicio
@authors: David Teófilo Garitagoitia Romero
"""


def home(request):
    """View function for home page of site."""
    # Render the HTML template index.html with the data in the context variable
    context = {
        # se cargan los libros con mayor score
        'top_books': Book.objects.order_by('-score')[0:5],
        # se cargan los libros más recientes
        'top_recent': Book.objects.order_by('-date')[0:5],
        # se carga el formulario de búsqueda
        'form': SearchForm()
    }
    return render(request, 'home.html', context=context)


"""
Clase para mostrar la lista de resultados de la búsqueda
@authors: Miguel Bugarín Carreira
"""


class SearchResultsView(generic.ListView):
    # los resultados son libros
    model = Book
    template_name = 'search_results.html'
    paginate_by = 5  # se implementa la paginación

    def get_queryset(self):
        # se hace una q search
        # primero se obtiene el valor introducido
        # get para que se emplee la url
        query = self.request.GET.get('q')
        # filtramos con los valores recibidos del form
        object_list = Book.objects.filter(
            Q(title__icontains=query) |
            Q(author__last_name__icontains=query) |
            Q(author__first_name__icontains=query)
        ).distinct()
        # distinct para resultados unicos
        return object_list  # retornamos resultado

    def get_context_data(self, **kwargs):
        context = super(SearchResultsView, self).get_context_data(**kwargs)
        q = self.request.GET.get('q')
        q = q.replace(" ", "+")
        context['searchq'] = q
        # pasamos mediante el contexto la string de búsqueda
        # la emplearemos posteriormente para paginación
        return context

# para poder ver los libros a detalle


"""
Clase para mostrar el detalle de un libro
@authors: David Teófilo Garitagoitia Romero
"""


"""class BookDetailView(generic.DetailView):
    model = Book
    def get_context_data(self, **kwargs):
        # Call the base implementation first to get the context
        context = super(BookDetailView, self).get_context_data(**kwargs)
        # Create any data and add it to the context
        # .filter(author__exact=context['object'])
        context['comment_list'] = Comment.objects.filter(book=self.object)
        context['cart_product_form'] = CartAddBookForm()
        return context"""


def BookDetailView(request, slug):
    try:
        book = Book.objects.get(slug=slug)
    except Exception as e:
        print(e)
        raise Http404("Book does not exist")
    comment_list = Comment.objects.filter(book=book)
    cart_product_form = CartAddBookForm()
    return render(request, 'catalog/book_detail.html',
                  {'book': book, 'comment_list': comment_list,
                   'cart_product_form': cart_product_form})


"""
Clase para poder ver los autores a detalle
@authors: Miguel Bugarín Carreira
"""


def AuthorDetailView(request, pk):
    try:
        author = Author.objects.get(author_id=pk)
    except Exception as e:
        print(e)
        raise Http404("Author does not exist")
    book_list = author.book_set.all()
    return render(request, 'catalog/author_detail.html',
                  {'author': author, 'book_list': book_list})


"""
Clase para mostrar la lista de libros
@author: David Teófilo Garitagoitia Romero
"""


class BookListView(generic.ListView):
    model = Book
    paginate_by = 10

    def get_context_data(self, **kwargs):
        # Call the base implementation first to get the context
        context = super(BookListView, self).get_context_data(**kwargs)
        # Create any data and add it to the context
        context['some_data'] = 'This is just some data'
        return context
