from django.test import Client, TestCase
from django.urls import reverse
import datetime
from dateutil.relativedelta import relativedelta

from .management.commands.populate import Command

###################
# You may modify the following variables
from .models import Author as Author
from .models import Book as Book
from faker import Faker

DETAIL_SERVICE = "detail"
SEARCH_SERVICE = "search"
SEARCH_TITLE = "Search"

SERVICE_DEF = {DETAIL_SERVICE: {
    "title": "",
},
    SEARCH_SERVICE: {
        "title": SEARCH_TITLE,
},
}
# PLease do not modify anything below this line
###################


class ServiceBaseTest(TestCase):
    def setUp(self):
        self.client1 = self.client
        self.client2 = Client()
        self.client3 = Client()
        self.populate = Command()
        self.populate.handle()

    def tearDown(self):
        self.populate.cleanDataBase()

    @classmethod
    def decode(cls, txt):
        return txt.decode("utf-8")


class CatalogServicesA(ServiceBaseTest):
    def test01_no_coincidences(self):
        """
        Comprueba que, cuando se busca una cadena sin coincidencias,
        se devuelve el resultado en blanco
        @authors: Miguel Bugarín Carreira
        """
        # Cadena utilizada para el ejemplo
        searchString = 'asdgfqwerg'

        # Querys para la búsqueda de los elementos coincidentes en la base
        aaBooks = Book.objects.filter(title__icontains=searchString)
        aaAuthor1 = Author.objects.filter(first_name__icontains=searchString)
        aaAuthor2 = Author.objects.filter(last_name__icontains=searchString)
        # Búsqueda de los elementos coincidentes en la pagina web
        response = self.client1.get(
            reverse(SEARCH_SERVICE) + '?q=%s' % searchString, follow=True)
        response_txt = self.decode(response.content)

        # Se añaden en response_txt los resultados obtenidos
        # de todas las páginas
        for i in range(int(response.context['paginator'].num_pages)+1):
            response = self.client1.get(
                reverse(SEARCH_SERVICE) + '?q=%s&page=%d' % (searchString, i),
                follow=True)
            response_txt += self.decode(response.content)
        # Compara los resultados obtenidos en la base con los obtenidos en
        # response_txt, ambos deberían ser ninguno si se utilizó una cadena
        # correcta
        for book in aaBooks:
            self.assertIn(book. title, response_txt)
        for author in aaAuthor1:
            for book in author.book_set.all():
                self.assertIn(book.title, response_txt)
        for author in aaAuthor2:
            for book in author.book_set.all():
                self.assertIn(book.title, response_txt)


class ViewTest(ServiceBaseTest):
    @classmethod
    def setUpTestData(cls):
        # Create 13 authors for pagination tests
        number_of_books = 13
        faker = Faker()
        for __ in range(number_of_books):
            title = faker.text(max_nb_chars=20)
            Book.objects.create(
                isbn=faker.isbn13(separator=''),
                title=title,
                price=faker.pydecimal(
                    left_digits=2, right_digits=4, positive=True, min_value=5),
                number_copies_stock=faker.random_int(0, 100),
                date=datetime.datetime.now() -
                relativedelta(years=faker.random_int(0, 500)),
                score=faker.random_int(0, 10),
                slug=title[0:40].replace(" ", "-"),
                summary=faker.text(max_nb_chars=1000),
            )
        for i in range(3):
            name = faker.name()
            first = name.split(' ')[0]
            second = name.split(' ')[1]
            Author.objects.create(
                first_name=first,
                last_name=second,
            )

    def test_view_url_exists_at_desired_location(self):
        response = self.client.get('/catalog/book')
        self.assertEqual(response.status_code, 200)

    def test_view_url_accessible_by_name(self):
        response = self.client.get(reverse('book-list'))
        self.assertEqual(response.status_code, 200)

    def test_view_uses_correct_template(self):
        response = self.client.get(reverse('book-list'))
        self.assertEqual(response.status_code, 200)
        self.assertTemplateUsed(response, 'catalog/book_list.html')

    def test_author_view(self):
        author = Author.objects.all()[0]
        response = self.client.get(
            reverse("author-detail", kwargs={'pk': author.author_id}))
        response_txt = self.decode(response.content)
        self.assertEqual(response.status_code, 200)
        self.assertFalse(response_txt.find(author.first_name) == -1)

    def test_home_view(self):
        response = self.client.get(reverse('home'))
        self.assertEqual(response.status_code, 200)
        response_txt = self.decode(response.content)
        self.assertFalse(response_txt.find("Top Scores Books") == -1)
        self.assertFalse(response_txt.find("Last Published Books") == -1)
        book = Book.objects.order_by('-score')[0]
        self.assertFalse(response_txt.find(book.title) == -1)
        book = Book.objects.order_by('-date')[0]
        self.assertFalse(response_txt.find(book.title) == -1)
