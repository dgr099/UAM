from django import forms

"""
Formulario para implementar la búsqueda
@authors: Miguel Bugarín Carreira
"""


class SearchForm(forms.Form):
    q = forms.CharField(label='search', widget=forms.TextInput(
        attrs={'placeholder': 'book title or author'}), max_length=300)
