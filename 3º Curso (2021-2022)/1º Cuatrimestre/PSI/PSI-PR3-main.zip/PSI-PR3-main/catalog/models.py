from django.db import models
from django.contrib.auth.models import User
from django.core.validators import MaxValueValidator, MinValueValidator
from pathlib import Path
# Create your models here.

# Used to generate URLs by reversing the URL patterns
from django.urls import reverse

"""
    Clase Autor
    @authors: Miguel Bugarín Carreira
"""


class Author(models.Model):

    # Atributos
    author_id = models.BigAutoField(
        auto_created=True, primary_key=True, serialize=False,
        verbose_name='ID')

    first_name = models.CharField(max_length=100)
    last_name = models.CharField(max_length=100)
    date_of_birth = models.DateField(null=True, blank=True)
    date_of_death = models.DateField('Died', null=True, blank=True)

    # Las listas de autores se ordenan por el apellido,
    # y en caso de haberlos iguales por el nombre
    class Meta:
        ordering = ['last_name', 'first_name']

    def get_absolute_url(self):
        # Devuelve la URL para acceder a los atributos de un autor
        return reverse('author-detail', args=[str(self.author_id)])

    def __str__(self):

        # String que representa el modelo del objeto

        return f'{self.last_name}, {self.first_name}'


"""
    Clase Comment
    @authors: Miguel Bugarín Carreira
"""


class Comment(models.Model):

    # Atributos
    comment_id = models.BigAutoField(
        auto_created=True, primary_key=True, serialize=False,
        verbose_name='ID')
    book = models.ForeignKey('Book', on_delete=models.CASCADE, null=True)
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    date = models.DateField(null=True)
    msg = models.CharField(max_length=300)

    def __str__(self):

        # String que representa el modelo del objeto

        return f'{self.user_id}, {self.date}'


"""
    Clase Book
    @authors: Miguel Bugarín Carreira
"""


class Book(models.Model):

    # Atributos

    isbn = models.CharField('ISBN', max_length=13, unique=True,
                            help_text='13 Character' +
                            '< a href="https://www.isbn-' +
                            'international.org/content/what-isbn" >' +
                            'ISBN number < /a >')
    title = models.CharField(max_length=200)
    price = models.DecimalField(max_digits=10, decimal_places=2)
    # Carpeta donde se guardan los archivos de imagen
    path_to_cover_image = models.FilePathField(path=Path(
        __file__).resolve().parent.joinpath('static/covers/'), max_length=101)
    number_copies_stock = models.IntegerField()
    date = models.DateField(null=True, blank=True)
    score = models.IntegerField(
        validators=[MaxValueValidator(10), MinValueValidator(0)])
    slug = models.SlugField(
        max_length=40, help_text='Book reference to integrate on URL',
        unique=True)
    summary = models.TextField(
        max_length=1000, help_text='Enter a brief description of the book')
    id = models.BigAutoField(
        auto_created=True, primary_key=True, serialize=False,
        verbose_name='ID')

    # relación many to many para mostrar autores de un libro
    author = models.ManyToManyField(Author)

    def __str__(self):

        # String que representa el modelo del objeto

        return self.title

    def get_absolute_url(self):

        # Devuelve la URL para acceder a los detalles (atributos) de un libro

        return reverse('detail', kwargs={'slug': self.slug})

    # Las listas de libros se ordenan según el título
    class Meta:
        ordering = ['title']
