from django.urls import path
from . import views

urlpatterns = [
    path('', views.home, name='home'),
    path('book', views.BookListView.as_view(), name='book-list'),
    # path('book/<str:slug>', views.BookDetailView.as_view(), name='detail'),
    path('book/<str:slug>', views.BookDetailView, name='detail'),
    path('author/<int:pk>', views.AuthorDetailView,
         name='author-detail'),
    path('search/', views.SearchResultsView.as_view(), name='search'),
]
