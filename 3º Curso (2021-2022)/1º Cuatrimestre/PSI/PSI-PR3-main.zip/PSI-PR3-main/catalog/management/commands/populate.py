# Populate database
# This file has to be placed within the
# catalog/management/commands directory in your project.
# If that directory doesn't exist, create it.
# The name of the script is the name of the custom command,
# that is, populate.py.
#
# execute python manage.py  populate
#
# use module Faker generator to generate data
# (https://zetcode.com/python/faker/)
import os
from random import randint
import datetime
from dateutil.relativedelta import relativedelta
from django.core.management.base import BaseCommand
from catalog.models import (Author, Book, Comment)
from django.contrib.auth.models import User
from faker import Faker
# define STATIC_PATH in settings.py
from bookshop.settings import STATIC_PATH
from PIL import Image, ImageDraw, ImageFont

FONTDIR = "/usr/share/fonts/truetype/freefont/FreeMono.ttf"

# The name of this class is not optional must be Command
# otherwise manage.py will not process it properly
#


class Command(BaseCommand):
    # helps and arguments shown when command python manage.py help populate
    # is executed.
    help = """populate database
           """

    # def add_arguments(self, parser):

    # handle is another compulsory name, do not change it"
    # handle function will be executed by 'manage populate'
    def handle(self, *args, **kwargs):
        # check a variable that is unlikely been set out of heroku
        # as DYNO to decide which font directory should be used.
        # Be aware that your available fonts may be different
        # from the ones defined here
        if 'DYNO' in os.environ:
            self.font = \
                "/usr/share/fonts/truetype/dejavu/DejaVuSansMono-Bold.ttf"
        else:
            self.font = \
                "/usr/share/fonts/truetype/freefont/FreeMono.ttf"

        self.NUMBERUSERS = 20
        self.NUMBERBOOKS = 30
        self.NUMBERAUTHORS = 10
        self.MAXAUTHORSPERBOOK = 3
        self.NUMBERCOMMENTS = self.NUMBERBOOKS * 5
        self.MAXCOPIESSTOCK = 30
        self.cleanDataBase()   # clean database
        # The faker.Faker() creates and initializes a faker generator,
        self.faker = Faker()
        self.user()
        self.author()
        self.book()
        self.comment()
        # check a variable that is unlikely been set out of heroku
        # as DYNO to decide which font directory should be used.
        # Be aware that your available fonts may be different
        # from the ones defined here
    """
    Función para limpiar la base de datos
    @author: David Teófilo Garitagoitia Romero
    """

    def cleanDataBase(self):
        # delete all models stored (clean table)
        # in database
        # también se encarga de eliminar las imagenes de covers
        Author.objects.all().delete()
        Comment.objects.all().delete()
        Book.objects.all().delete()
        Comment.objects.all().delete()
        User.objects.all().delete()
        User.objects.create_superuser(
            'alumnodb', 'admin@myproject.com', 'alumnodb')
        # ahora eliminamos las imagenes de covers
        folder = os.path.join(STATIC_PATH, 'covers')
        for filename in os.listdir(folder):
            file_path = os.path.join(folder, filename)
            try:
                if os.path.isfile(file_path) or os.path.islink(file_path):
                    os.unlink(file_path)
            except Exception as e:
                print(e)
    """
    Función para crear usuarios aleatorios en la base de datos
    @author David Teófilo Garitagoitia Romero
    """

    def user(self):
        " Insert users"
        # remove pass and ADD CODE HERE.
        for i in range(self.NUMBERUSERS):
            name = self.faker.name()
            first = name.split(' ')[0]
            second = name.split(' ')[1]
            User.objects.create_user(
                username=name[0]+second+str(self.faker.random_int(0, 100)),
                password=self.faker.password(),
                email=name.replace(' ', '') + '@' + 'mail.com',
                first_name=first,
                last_name=second)
    """
    Función para añadir autores en la base de datos
    @authors: David Teófilo Garitagoitia Romero
    """

    def author(self):
        " Insert authors"
        # remove pass and ADD CODE HERE
        for i in range(self.NUMBERAUTHORS):
            name = self.faker.name()
            first = name.split(' ')[0]
            second = name.split(' ')[1]
            date_of_death = None
            date_of_birth = None
            # genera un numero random, si es par tiene fecha de muerte
            if(self.faker.random_int(0, 10) % 2 == 0):
                years = relativedelta(years=self.faker.random_int(20, 100))
                date_of_birth = datetime.datetime.now() - years - \
                    relativedelta(years=randint(20, 500))
                date_of_death = date_of_birth + years
            else:
                date_of_birth = self.faker.date_of_birth()
            author = Author(
                first_name=first,
                last_name=second,
                date_of_birth=date_of_birth,
                date_of_death=date_of_death
            )
            author.save()
    """
    Función para crear las covers de los libros
    @author: Profesores PSI
    """

    def cover(self, book):
        """create fake cover image.
           This function creates a very basic cover
           that show (partially),
           the primary key, title and author name"""

        img = Image.new('RGB', (200, 300), color=(73, 109, 137))
        # your font directory may be different
        fnt = ImageFont.truetype(
            self.font,
            28, encoding="unic")
        d = ImageDraw.Draw(img)
        d.text((10, 100), "PK %05d" %
               book.pk, font=fnt, fill=(255, 255, 0))
        d.text((20, 150), book.title[:15], font=fnt, fill=(255, 255, 0))
        d.text((20, 200), "By %s" % str(
            book.author.all()[0])[:15], font=fnt, fill=(255, 255, 0))
        img.save(os.path.join(STATIC_PATH, book.path_to_cover_image))
    """
    Función para añadir libros a la base de datos
    @author: David Teófilo Garitagoitia Romero
    """

    def book(self):
        " Insert books"
        # remove pass and ADD CODE HERE
        for i in range(self.NUMBERBOOKS):
            # son max 200 pero pongo 20 para que no sea tan largo
            title = self.faker.text(max_nb_chars=20)
            book = Book(
                isbn=self.faker.isbn13(separator=''),
                title=title,
                price=self.faker.pydecimal(
                    left_digits=2, right_digits=4, positive=True, min_value=5),
                number_copies_stock=self.faker.random_int(0, 100),
                date=datetime.datetime.now() -
                relativedelta(years=self.faker.random_int(0, 500)),
                score=self.faker.random_int(0, 10),
                slug=title[0:40].replace(" ", "-"),
                summary=self.faker.text(max_nb_chars=1000),
            )
            book.save()
            book.path_to_cover_image = "covers/" + str(book.pk) + ".png"
            # le asigno algún autor al azar
            n_authors = 0
            while (True):
                book.author.add(Author.objects.all()[
                                self.faker.random_int(0, self.NUMBERAUTHORS
                                                      - 1)])
                n_authors += 1
                # añadimos autores hasta que salga par o se pase del max
                if (self.faker.random_int(0, 10) % 2 == 0
                        or n_authors == self.MAXAUTHORSPERBOOK):
                    break
            self.cover(book)
            book.save()
    """
    Función para añadir comentarios
    @author: David Teófilo Garitagoitia Romero
    """

    def comment(self):
        " Insert comments"
        # remove pass and ADD CODE HERE
        for i in range(self.NUMBERCOMMENTS):
            com = Comment(
                book=Book.objects.all()[self.faker.random_int(
                    0, self.NUMBERBOOKS - 1)],
                user=User.objects.all()[self.faker.random_int(
                    0, self.NUMBERUSERS - 1)],
                date=datetime.datetime.now() -
                relativedelta(day=self.faker.random_int(0, 100)),
                msg=self.faker.text(max_nb_chars=300),
            )
            com.save()
