from django.contrib import admin

# Register your models here.
from .models import Author, Comment, Book
admin.site.register(Author)
admin.site.register(Comment)
admin.site.register(Book)
