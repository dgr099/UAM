from django import forms
from django.contrib.auth.models import User
from django.contrib.auth.forms import UserCreationForm

"""
Clase con el formulario para registrar usuarios que hereda
de user creation form
"""


class SignUpForm(UserCreationForm):
    first_name = forms.CharField(max_length=30, help_text='First Name')
    last_name = forms.CharField(max_length=32, help_text='Last name')
    username = forms.CharField(help_text='User name')
    email = forms.EmailField(
        max_length=64, help_text='Enter a valid email address')
    password1 = forms.CharField(
        widget=forms.PasswordInput(), help_text='Password')
    password2 = forms.CharField(
        widget=forms.PasswordInput(), help_text='Password Again')

    class Meta:
        model = User
        fields = ("username", "email", "password1",
                  "password2", "first_name", "last_name")

    def save(self, commit=True):
        user = super(SignUpForm, self).save(commit=False)
        user.email = self.cleaned_data['email']
        if commit:
            user.save()
        return user
