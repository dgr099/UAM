from django.shortcuts import render, redirect
from .forms import SignUpForm
from django.contrib.auth import login

"""
Función para definir la vista del signup
@author: David Teófilo Garitagoitia Romero
"""


def signup(request):
    if request.method == 'POST':
        form = SignUpForm(request.POST)
        if form.is_valid():
            user = form.save()
            """username = form.cleaned_data.get['username']
            raw_password = form.cleaned_data['password1']
            email = form.cleaned_data['email']
            first_name = form.cleaned_data['first_name']
            last_name = form.cleaned_data['last_name']
            user = authenticate(username=username, password=raw_password)"""
            login(request, user)
            return redirect('/catalog')
    else:
        form = SignUpForm()
    return render(request, 'signup.html', {'form': form})
