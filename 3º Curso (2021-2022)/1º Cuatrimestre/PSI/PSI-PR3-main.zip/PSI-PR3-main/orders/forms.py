from django import forms
from orders.models import Order


class CartAddBookForm(forms.Form):
    # Permite añadir al carro de la compra un nº de ejemplares DE UN SOLO LIBRO
    quantity = forms.IntegerField(
        help_text='BOOK UNITS', required=True)  # Limite maximo de libros?
    update = forms.BooleanField(required=False, initial=False,
                                widget=forms.HiddenInput)


class OrderCreateForm(forms.ModelForm):
    class Meta:
        model = Order
        fields = ['first_name', 'last_name',
                  'address', 'email', 'city', 'postal_code']
