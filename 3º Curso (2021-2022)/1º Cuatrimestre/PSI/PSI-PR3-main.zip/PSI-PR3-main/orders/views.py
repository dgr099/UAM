from django.shortcuts import render, redirect, get_object_or_404
from .models import OrderItem
from .forms import CartAddBookForm, OrderCreateForm
from catalog.models import Book
from .cart import Cart
from django.utils import timezone
# Create your views here.


def cart_add(request, slug):
    """ add the book with slug "book_slug" to the
    shopping cart. The number of copies to be bought
    may be obtained from the form CartAddBookForm """
    if request.user.is_authenticated:
        cart = Cart(request)
        # se recogen los datos del form
        if request.method == 'POST':
            form = CartAddBookForm(request.POST)
            # si el formulario es correcto se procede con la función
            if(form.is_valid()):
                # se obtiene el slug del libro y las unidades requeridas del
                # mismo, obtenidas del form
                book = get_object_or_404(Book, slug=slug)
                quantity = int(request.POST.get('quantity'))
                update = bool(request.POST.get('update'))
                cart.add(book, quantity, update)
                return redirect("cart_list")
    return redirect('home')


def shoppingCart(request):
    """View function for home page of site."""
    # Render the HTML template index.html with the data in the context variable
    if request.user.is_authenticated:
        context = {
            'cart': Cart(request),
            # le pasamos el form
            # 'form': SearchForm()
            'finish': False
        }
        return render(request, 'shoppCart.html', context=context)
    return redirect('home')


def cart_remove(request, slug):
    """remove the book with the 'book slug' from the shopping cart'"""
    cart = Cart(request)
    # se obtiene el slug del libro y las unidades requeridas del mismo,
    # obtenidas del form
    book = get_object_or_404(Book, slug=slug)
    cart.remove(book)
    return redirect("cart_list")


def order_create(request):
    cart = Cart(request)
    if request.method == 'POST':
        form = OrderCreateForm(request.POST)
        if form.is_valid():
            order = form.save()
            order.paid = True
            order.created = timezone.localtime(timezone.now())
            order.save()
            for item in cart:
                OrderItem.objects.create(order=order, book=item['book'],
                                         price=str(item['price']),
                                         quantity=item['quantity'])
            # clear the cart
            cart.clear()
            return render(request, 'shoppCart.html', context={'finish': True})
    else:
        form = OrderCreateForm()
        return render(request, 'create.html',
                      {'cart': cart, 'form': form})
