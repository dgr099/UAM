from django.urls import path
from django.contrib.auth.decorators import login_required
from . import views

urlpatterns = [
    path('cart_list', login_required(views.shoppingCart), name='cart_list'),
    path('cart_remove/<str:slug>', views.cart_remove, name='cart_remove'),
    path('cart_add/<str:slug>', login_required(views.cart_add),
         name='cart_add'),
    path('order_create', views.order_create, name='order_create')
]
