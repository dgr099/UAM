from django.db import models
from django.core.validators import MaxValueValidator, MinValueValidator
from decimal import Decimal
# Create your models here.


class Order(models.Model):
    # order(order id, first name, last name, email, address, postal code,
    # city, created,
    # updated, paid)
    # Atributos
    order_id = models.BigAutoField(
        auto_created=True, primary_key=True, serialize=False,
        verbose_name='ID')

    first_name = models.CharField(max_length=100)
    last_name = models.CharField(max_length=100)
    email = models.CharField(max_length=100)
    address = models.CharField(max_length=100)
    postal_code = models.CharField(max_length=100)
    city = models.CharField(max_length=100)
    created = models.DateField(null=True)
    updated = models.DateField(null=True, auto_now=True)
    paid = models.BooleanField(null=True, default=False)

    class Meta:
        ordering = ['last_name', 'first_name']

    # def get_absolute_url(self):
        # Devuelve la URL para acceder a los atributos de un autor
        # return reverse('author-detail', args=[str(self.author_id)])
    def __str__(self):
        # String que representa el modelo del objeto
        return f'{self.last_name}, {self.first_name}'

    def get_total_cost(self):
        price = 0
        items = OrderItem.objects.filter(order=self.order_id)
        for item in items:
            aux = format(float(item.price)*int(item.quantity), '.2f')
            price += Decimal(aux)
        return price

    """def items(self):
        return OrderItem.objects.filter(order=self.order_id)"""


class OrderItem(models.Model):
    # orderItem(order item id, order↑, book↑, price, quantity)
    # Atributos
    order_item_id = models.BigAutoField(
        auto_created=True, primary_key=True, serialize=False,
        verbose_name='ID')
    order = models.ForeignKey(
        'Order', on_delete=models.CASCADE, null=True, related_name="items")
    book = models.ForeignKey(
        'catalog.Book', on_delete=models.CASCADE, null=True)
    price = models.DecimalField(max_digits=6, decimal_places=2)
    quantity = models.IntegerField(
        validators=[MaxValueValidator(10), MinValueValidator(0)])

    # Las listas de autores se ordenan por el apellido,
    # y en caso de haberlos iguales por el nombre
    class Meta:
        ordering = ['order_id']

    # def get_absolute_url(self):
        # Devuelve la URL para acceder a los atributos de un autor
        # return reverse('author-detail', args=[str(self.author_id)])

    def __str__(self):
        # String que representa el modelo del objeto
        return f'{self.order_id}, {self.book}, {self.price}, {self.quantity}'
